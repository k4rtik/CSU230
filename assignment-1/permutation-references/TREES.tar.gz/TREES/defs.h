
#define WORDSIZE 32
#define false 0
#define true 1
#define BETTER 1
#define EQUAL  0
#define WORSE -1
#define BLANK ' '
#define COMMA ','
#define TAB '	'
#define NEWLINE '\n'
#define SEMICOLON ';'
#define RBRACE '}'
#define LBRACE '{'
#define ComputeWords(n) (WORDS=n/WORDSIZE+1)
#define decreasing -1
#define increasing  1
#define Min(x,y) ((x<y)?x:y)
