#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "base.h"
#include "setlib.h"

#define nB 47
#define nV 26

univeres 
